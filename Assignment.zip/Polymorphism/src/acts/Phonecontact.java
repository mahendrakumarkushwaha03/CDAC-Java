package acts;

public class Phonecontact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Contact c = new Contact();
		c.addContact("Anuj","75332113");
		c.addContact("Anuj","75332113","ertaasdgklsda@gmail");
		c.addContact("Anuj");
	}

}

class Contact{
	
	String name;
	String phoneNumber; 
	String email;
	
	void addContact(String name, String phoneNumber)
	{
		System.out.println(name + phoneNumber);
	}
	
	void addContact(String name, String phoneNumber,String email)
	{
		System.out.println(name + phoneNumber + email);
	}
	
	void addContact(String name)
	{
		System.out.println("Not available..!!");
	}
}



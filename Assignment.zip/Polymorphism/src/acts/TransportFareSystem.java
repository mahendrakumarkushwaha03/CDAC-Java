package acts;

public class TransportFareSystem {

	public static void main(String[] args) {
		
		
		Transport t;
		t = new Bus(12);
		t.calculateFare();
		
		t = new Train(12);
		t.calculateFare();
		
		t = new Taxi(12);
		t.calculateFare();

	}

}

class Transport{
	double distance;
	Transport(double distance) {
		this.distance = distance;
	}
	
	void calculateFare(){
		System.out.println("Fare added..!!");
	}
}

class Bus extends Transport{

	Bus(double distance) {
		super(distance);
	}
	void calculateFare(){
		System.out.println("Bus Fare is :"+(distance*5));
	} 

}	


class Train extends Transport{

	Train(double distance) {
		super(distance);
	}
	void calculateFare(){
		System.out.println("Train Fare is :"+(distance*3));
	} 

}

class Taxi  extends Transport{

	Taxi (double distance) {
		super(distance);
	}
	void calculateFare(){
		System.out.println("Taxi Fare is :"+((distance*12)+50));
	} 

}	

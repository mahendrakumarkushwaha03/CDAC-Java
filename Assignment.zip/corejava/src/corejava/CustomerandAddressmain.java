package corejava;
import java.util.Scanner;
public class CustomerandAddressmain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Street :");
		String Street = sc.next();
		System.out.println("Enter city :");
		String city = sc.next();
		System.out.println("Enter pin :");
		int pin = sc.nextInt();
		Address a = new Address(Street,city,pin);
		
		
		System.out.println("Enter Customer Id: ");
		int CustomerId = sc.nextInt();
		System.out.println("Enter Customer Name: ");
		String CustomerName = sc.next();
		Customer c = new Customer(CustomerId,CustomerName,a);
		c.display();

	}

}

package corejava;

class Payment {
	
	public void processPayment(double amount){
		System.out.println("Processing generic payment");
	}
}

class CreditCard extends Payment{
	@Override
	public void processPayment(double amount){
	System.out.println("Processing Credit Card payment of $[amount] (2% fee applied)");
	}
}

class UPI extends Payment{
	@Override
	public void processPayment(double amount){
		System.out.println("Processing UPI payment of $[amount] (No fee)");
		}
	
}

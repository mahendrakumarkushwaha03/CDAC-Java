package corejava;
import java.util.Scanner;

public class Department{
	Scanner sc = new Scanner(System.in);
	
	int deptId;
	String deptName;
	
//	Department(int deptId, String deptName) {
//		this.deptId = deptId;
//		this.deptName = deptName;
//	}
//	
	Department(int deptId, String deptName) {
		System.out.println("Enter number: ");
		this.deptId = sc.nextInt();
		this.deptName = sc.next();
	}
	

}

class Employee{
	int EmployeeId;
	String EmployeeName;
	int Salary;
	Department Dept;
	
	Employee(int employeeId, String employeeName, int salary,Department Dept){
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		Salary = salary;
	}
	void Employee(){
		float annualSal = Salary *12;
		System.out.println("Annual Salary is : "+ annualSal);
	}
	void EmpDetail() {
		System.out.println(EmployeeId);
		System.out.println(EmployeeName);
		System.out.println(Salary);
		System.out.println(Dept.deptId + Dept.deptName);
	}
	
	
}

package corejava;

public class Vehicle{
	String brand;
	int price;
	
	Vehicle(String brand, int price){
		this.brand = brand;
		this.price = price;
	}
	
	void Displaybrand(){
		System.out.println("brand is : " + brand);
		System.out.println("price is :" + price);
		
	}
	
}

class Car extends Vehicle{
	double milage;
	
	
	
	    Car(String brand, int price, double milage) {
		super(brand, price);
	}



	void calcsaleval(){
		double val = price - price * 0.20;
		System.out.println("Reasle value is : "+ val);
	}
}

class Bike extends Vehicle{

	    Bike(String brand,int price, double milage) {
		super(brand, price);
	}
	
	void calcinsurance(){
		double val = price - price * 0.05;
		System.out.println("Reasle value is : "+ val);
	}
	
}


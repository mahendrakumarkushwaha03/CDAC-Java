package corejava;
import java.util.Scanner;
public class Address {
	String Street;
	String city;
	int pin;
	
	Address(String Street, String city, int pin) {
		this.Street = Street;
		this.city = city;
		this.pin = pin;
	}
}

class Customer{
	Scanner sc = new Scanner(System.in);
	int customerId;
	String customerName;
	Address add;
	
	Customer(int customerId, String customerName, Address add) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.add = add;
		
	}
	void display(){
		System.out.println("Customer Id is : "+ customerId);
		System.out.println("Customer Name is : "+ customerName);
		System.out.println("Customer Address is : "+ add.Street + add.city + add.pin);
		
	}
}
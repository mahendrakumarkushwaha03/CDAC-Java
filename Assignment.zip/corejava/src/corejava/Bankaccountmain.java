package corejava;
import java.util.Scanner;

public class Bankaccountmain {

	public static void main(String[] args) {
		
		SavingsAccount s = new SavingsAccount(102102,200000,0.05);
		s.Calcinterest();
		s.displayBal() ;
	}

}

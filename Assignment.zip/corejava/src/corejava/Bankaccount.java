package corejava;
import java.util.Scanner;

public class Bankaccount {
	Scanner sc = new Scanner(System.in);
	
	int account;
	double balance;
	
	Bankaccount(int account, double balance) {
		this.account = account;
		this.balance = balance;
	}

	
	
	void displayAccount() {
		System.out.println("Account Number :" + account);
		System.out.println("Balance : " + balance);
	}
}

class SavingsAccount extends Bankaccount{
	double interestRate;
	
	SavingsAccount(int account, double balance,double interestRate){
		super(account, balance);
		this.interestRate = interestRate;
	}
	
	void Calcinterest() {
		double Calir = (balance * interestRate);
		super.displayAccount();
		System.out.println("Interest is : " + Calir);
	}
	
	void displayBal() {
		balance = balance + (balance * interestRate);
		System.out.println("Balance is : " + balance);
	}
	
}

package corejava;

public class VehicleSystem {

	public static void main(String[] args) {
		Car c = new Car("Tata", 200000,40);
		Bike b = new Bike("Tata",200000,40);
		c.calcsaleval();
		b.calcinsurance();
	}

}

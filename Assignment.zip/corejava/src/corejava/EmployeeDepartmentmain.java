package corejava;
import java.util.Scanner;
public class EmployeeDepartmentmain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Department d = new Department();
		
	}

}

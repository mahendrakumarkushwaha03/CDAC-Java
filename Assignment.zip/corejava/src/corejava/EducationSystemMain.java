package corejava;

public class EducationSystemMain {

	public static void main(String[] args) {
		GraduateStudent g = new GraduateStudent("Anuj",18,80,"DBDA");
		g.calculategrade();
		g.eligibility();
	}

}

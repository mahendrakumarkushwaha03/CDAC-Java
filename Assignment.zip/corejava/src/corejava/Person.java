package corejava;

public class Person{
		String name;
		int age;
		
		Person(String name, int age) {
			this.name = name;
			this.age = age;
		}
}

class Student extends Person{
	float marks;

	Student(String name, int age, float marks) {
		super(name, age);
	}
	
}

class GraduateStudent extends Student{
	String Specsilization;
	

		GraduateStudent(String name, int age, float marks, String specsilization) {
		super(name, age, marks);
		Specsilization = specsilization;			
		}
		void calculategrade() {
				if(marks>=75) {
					System.out.println("Distinction");
				}
				else if((marks>=60) && (marks<74)) {
					System.out.println("First Class..!!!");
				}
				else if(marks<60){
					System.out.println("Pass..!!");
				}
//				else {
//					System.out.println("Fail..");
//				}
				
	}
		void eligibility()
		{
			if(marks>=65) {
				System.out.println("It is eligible for placement");
			}
			else if (marks<65)
			{
				System.out.println("Not eligible..!!!");
			}
		}
		
}
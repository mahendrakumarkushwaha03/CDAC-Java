package corejava;
class Emp{
	String name;
	double baseSalary;

	
	Emp(String name, double baseSalary) {
		this.name = name;
		this.baseSalary = baseSalary;
	}
	
}

class Manager extends Emp{
	
	Manager(String name, double baseSalary) {
		super(name,baseSalary);
	}

	void calculateSalary(){
		double totalSalary = baseSalary + (baseSalary * 0.20);
        System.out.println("Manager Name: " + name);
        System.out.println("Final Salary (with 20% bonus): ₹" + totalSalary);
	}
}

class Developer extends Emp{
	
	Developer(String name, double baseSalary) 
	{
		super(name, baseSalary);
	}

	void calculateSalary()
	{
		double totalSalary = baseSalary + (baseSalary * 0.10);
        System.out.println("Developer Name: " + name);
        System.out.println("Final Salary (with 10% bonus): ₹" + totalSalary);
	}
	
}



public class EmpSalSystem {

	public static void main(String[] args) 
	{
		
	Manager m =new Manager("Anuj", 400000.0);
		m.calculateSalary();
		 
		
		

	}

}

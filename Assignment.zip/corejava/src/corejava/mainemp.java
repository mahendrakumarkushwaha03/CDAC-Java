package corejava;

public class mainemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

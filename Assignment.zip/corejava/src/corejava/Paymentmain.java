package corejava;

public class Paymentmain {

	public static void main(String[] args) {
		Payment p = new CreditCard();
		p.processPayment(55.0);
		
		Payment p1 = new Payment();
		p1.processPayment(65.0);
		
		Payment p11 = new UPI();
		p11.processPayment(57.0);
	}

}

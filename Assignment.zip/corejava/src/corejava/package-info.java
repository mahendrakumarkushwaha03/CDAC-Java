package corejava;
import java.util.Scanner;

class Studentresult{
	Scanner sc = new Scanner(System.in);
	int id;
	String name;
	int marks;
	
	Studentresult(){
		System.out.println("Enter Id : ");
		id = sc.nextInt();
		System.out.println("Enter Name : ");
		name = sc.next();
		System.out.println("Enter Marks : ");
		marks = sc.nextInt();
	}
	
	void checkResult() {
		if (marks>=50)
			System.out.println("Pass..!!");
		else {
			System.out.println("Fail..!!");
		}
	}
	
	void displaystudent(){
		System.out.println("Student Id : " + id);
		System.out.println("Student Name : " + name);
		System.out.println("Student Marks : " + marks);
	}

	public static void main(String[] args) {
		
		Studentresult s1 = new Studentresult();
		s1.checkResult();
		s1.displaystudent();
		
		
	}	
}


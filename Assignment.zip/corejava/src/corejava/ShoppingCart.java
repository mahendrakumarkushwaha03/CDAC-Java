package corejava;

class Shopping {
	double price;
	
//first Method
	void calculateBill(double price)
	{
				this.price = price;
				double calc = price *1;
				System.out.println("Final Bill is : " + calc);
	}
	
//dusri Method	
	void calculateBill(double price, double quantity) 
	{
			double calc = price *quantity;
			System.out.println("Final Bill is : " + calc);
	}
	
//Teesri Method	
	void calculateBill(double price, double quantity, double discount) {
			double total = price * quantity;
			double calc = total - (total * discount); 
			System.out.println("Final Bill after discount: " + calc);
	}
}

public class ShoppingCart{
public static void main(String[] args) {
	Shopping s = new Shopping();
	s.calculateBill(500.0);
	s.calculateBill(500.0,3.0);
	s.calculateBill(500.0,3.0,2);
}
}


package abstraction;

public class VehicleManagementSys {

	public static void main(String[] args){
		Vehicle v;
		v = new Car("Sata", 50);
		v.displayVehicle();
		v.calculateMilage();
		System.out.println("");
		v= new Bike("Gonda", 70);
		v.displayVehicle();
		v.calculateMilage();
	}

}

abstract class Vehicle{
	String vehicleName;
	double speed;
	
	Vehicle(String vehicleName, double speed)
	{
		this.vehicleName = vehicleName;
		this.speed = speed;
	}
	
	void calculateMilage()
	{
		System.out.println("Calculate Milage..!!");
	}
	
	void displayVehicle()
	{
		System.out.println("Vehicle Name : "+ vehicleName);
		System.out.println("Vehicle Speed : "+ speed);
	}
}

class Car extends Vehicle{
	Car(String vehicleName, double speed) {
		super(vehicleName, speed);
	}
	
	void displayCar()
	{
		super.displayVehicle();
	}
	
	void calculateMilage()
	{
		System.out.println("Milage is 25 km/ litre..!!");
	}
	
	
}

class Bike extends Vehicle{
	
	Bike(String vehicleName, double speed)
	{
		super(vehicleName, speed);
	}
	
	void displayBike()
	{
		super.displayVehicle();
	}
	
	void calculateMilage()
	{
		System.out.println("Calculate Milage is 50 km/ litre..!!");
	}
	
	
}


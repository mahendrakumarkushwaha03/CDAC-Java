package abstraction;

public class EmployeeSalarySys {

	public static void main(String[] args) {
		
		Employee e1 = new FullTimeEmployee("Anuj", 123, 500000.0);
		Employee e2 = new PartTimeEmployee("Cheeta", 321, 200000.0);

        System.out.println("--- Full-Time Employee ---");
        e1. EmpDetails();
        e1.calculateBonus();

        System.out.println("\n--- Part-Time Employee ---");
        e2. EmpDetails();
        e2.calculateBonus();
		

	}

}

abstract class Employee{
	String empName;
	int EmpId;
	double Salary;
	
//	constructor	
	Employee(String empName, int EmpId, double Salary) {
		this.empName = empName;
		EmpId = EmpId;
		this.Salary = Salary;
	}
//	method	
	void calculateBonus() {
		
	}
//	method	
	void EmpDetails() {
		System.out.println("Enployee Name : " + empName);
		System.out.println("Enployee Id : " + EmpId);
		System.out.println("Enployee Salary : " + Salary);
		
	}
}


class FullTimeEmployee extends Employee{

//	constructor
	FullTimeEmployee(String empName, int EmpId, double Salary) {
		super(empName, EmpId, Salary);
	}
	
	void FullTimeEmpDetails() {
		super.EmpDetails();
	}
	
	void calculateBonus() {
		double total = Salary + (Salary *0.2);
		System.out.println("Full Time Emp Salary with Bonus is :"+ total);
		
	}
	
}

class PartTimeEmployee extends Employee{

//	constructor
	PartTimeEmployee(String empName, int EmpId, double Salary) {
		super(empName, EmpId, Salary);
	}
	
	void PartTimeEmpDetails() {
		super.EmpDetails();
	}
	
	void calculateBonus() {
		double total = Salary + (Salary *0.2);
		System.out.println("Full Time Emp Salary with Bonus is :"+ total);
		
	}
	
}


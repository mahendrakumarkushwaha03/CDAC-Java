package abstraction;

public class PaymentGateway {

	public static void main(String[] args) {
	
	}
}

interface Payment{
	
	void makePayment(double amount);
}

class CreditCardPayment implements Payment{
	 String cardNumber;;
	 String cardHolderName ;
	 double availableLimit; 
	 String total;
	 
	 
	 public CreditCardPayment(String cardNumber, String cardHolderName, double availableLimit, String total) {
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.availableLimit = availableLimit;
		this.total= total;
	}


	void makePayment(double amount,double availableLimit) {
		 
		availableLimit = 6000;
		System.out.println("Processing Credit Card Payment...");
		
		if(cardNumber.length()==16 && availableLimit ==6000 ){
			double total = availableLimit - amount; 
			System.out.println("total amount"+total);
			System.out.println("payment successful");
			System.out.println("Amount: $" + amount + " charged to Card: " + cardNumber);
			System.out.println("Transaction Successful!\n");
		}
			
		
		else {
			System.out.println("Insufficient amount");
	}
	
		
class Upipayment implements  Payment{
		String upiId;
		double balance;
	
	

	public Upipayment(String upiId, double balance) {
			this.upiId = upiId;
			this.balance = balance;
		}



	void makePayment(String upiId,double balance) {
		 balance =6000;
		 
		 if (upiId.contains("@")){
			 
			 System.out.println()
		 
			 System.out.println("payment successfull");
		 }
		
	}
}

	public CreditCardPayment() {
		super();
		// TODO Auto-generated constructor stub
	}
}


package abstraction;
import java.util.Scanner;

public class PaymentG {

	public static void main(String[] args) {
		 	Scanner sc = new Scanner(System.in);
	        Payment p;
	        
	        System.out.println("===== Payment Gateway =====");
	        System.out.println("1. Credit Card");
	        System.out.println("2. UPI");
	        System.out.print("Choose Payment Method: ");
	        
	        int choice = sc.nextInt();
	        
	        System.out.print("Enter Amount: ");
	        double amount = sc.nextDouble();
	        sc.nextLine();
	        
                System.out.print("Enter Card Number: ");
                String cardNumber = sc.next();

                System.out.print("Enter Card Holder Name: ");
                String name = sc.next();

                System.out.print("Enter Available Limit: ");
                double limit = sc.nextDouble();

                p = new CreditCardPay(cardNumber,name,limit);
                p.makePayment(amount);
           
                
       
	}

}

//Interface
interface Payment{
 void makePayment(double amount);
}

//		Credit card Pay
class CreditCardPay implements Payment{
	 String cardNumber;
	 String cardHolderName ;
	 double availableLimit; 
	 String status = "";

	 
//	 Constructor
	 public CreditCardPay(String cardNumber, String cardHolderName, double availableLimit){
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.availableLimit = availableLimit;
	}
	 
//	 Payment method
	@Override
	public void makePayment(double amount) {
		  System.out.println("\n----- Credit Card Transaction -----");
		if(cardNumber.length()==16) {
			if (amount<=availableLimit) {
				availableLimit -= amount;
				status = "Payment SuccessFull";
	            System.out.println("Payment Successful");
	            
	            
	            System.out.println("Card Holder Name: " + cardHolderName);
	            System.out.println("Amount Paid: ₹" + amount);
	            System.out.println("Remaining Limit: ₹" + availableLimit);
	            System.out.println("Transaction Status: ");
			}
			else {
				System.out.println("Invalid Card / Insufficient Limit");
			}
			
		}
		else {
			System.out.println("Invalid Card / Insufficient Limit" + status);
		}
	}

}



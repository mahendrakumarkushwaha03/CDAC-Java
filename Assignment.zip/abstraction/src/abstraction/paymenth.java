package abstraction;

public class paymenth {

}
interface payment{
	void makepayment(double amount);
}
CreditCardPayment implements payment{
   int cardNumber, String "cardHolderName, availableLimit
}
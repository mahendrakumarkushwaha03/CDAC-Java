module abstraction {
}
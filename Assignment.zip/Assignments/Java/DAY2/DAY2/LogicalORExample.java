package cdac;

public class LogicalORExample 
{

	public static void main(String[] args) 
	{
	
		boolean isStaff=false;
		boolean iswblStudent = false;
		
			
		if(isStaff || iswblStudent)
		{
			System.out.println("Access grandted");
		}else
			System.out.println("access denied");
		
		
		
		
		
		
		
		
		
	}
	
	
}

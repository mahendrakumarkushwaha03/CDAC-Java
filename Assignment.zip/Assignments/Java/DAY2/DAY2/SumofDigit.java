package cdac;

import java.util.Scanner;

public class SumofDigit 
{

	public static int findsumofDigit(int num)
	{
		
		
		
		System.out.println("finding sum of digit"  + num);
		int digit;
		int sum=0;
		while(num!=0)
		{
			
		digit = 	num%10;
	    num = num/10;
	    sum = sum +digit;
			
		}
		
		//System.out.println(sum);
		
		return sum;
		
	}
	
	public static void main(String[] args) 
	{
	
		System.out.println("enter the data");
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();

		
		
		//1234
		
		int sumofdigit=findsumofDigit(num);
		System.out.println("inside the main");
		System.out.println(sumofdigit);
		
		
	}
	
	
}

package cdac;

import java.util.Scanner;

public class SwitchCaseExample 
{

	
	
	
	
	public static void main(String[] args) 
	{
	
		while(true)
		{
		System.out.println("1. create");
		System.out.println("2. delete");
		System.out.println("3. update");
		System.out.println("4. Select");
		System.out.println("5. exit");
		
		System.out.println("enter the option");
		Scanner s = new Scanner(System.in);
		int op = s.nextInt();

		switch(op)
		{
		
		case 1 : EmployeeManagement.create();
		break;
		case 2 : EmployeeManagement.delete();
		break;
		case 3 : System.out.println("record updated");
		break;
		case 4 : System.out.println("recored displayed");
		break;
		case 5: System.exit(0);
		default : System.out.println("invalid option");
		
		
		}
		
		}
		
		
		
	}	
	
	
	
	
	
}

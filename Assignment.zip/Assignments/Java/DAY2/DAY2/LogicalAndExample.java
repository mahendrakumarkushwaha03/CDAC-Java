package cdac;

public class LogicalAndExample 
{

	
	public static void main(String[] args) 
	{
	
		
		String uname = "admin";
		String pwd = "admin123";
		
		
		if(uname == "admin" && pwd == "admin123")
		{
			System.out.println("valid user access granted");
		}else
			System.out.println("invalid userid and passwd");
		
		
		
		
		
	}
	
}

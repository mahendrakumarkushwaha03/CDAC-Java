package cdac;

import java.util.Scanner;

public class ScannerExample 
{

	public static void main(String[] args) 
	{
	
		System.out.println("enter the emp details");
		Scanner s = new Scanner(System.in);
		int empno = s.nextInt();
		String name = s.next();
		float sal = s.nextFloat();
		
		
		System.out.println(empno);
		System.out.println(name);
		System.out.println(sal);
		
		
		
		
	}
	
}

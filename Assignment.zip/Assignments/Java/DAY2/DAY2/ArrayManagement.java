package cdac;

import java.util.Scanner;

public class ArrayManagement 
{

	public static int sumofArrayElement(int[] num) 
	{
		System.out.println("inside sumofArrayElement");
		int sum =0;
		
		for(int ele :num)
		{
			sum = sum+ele;
		}
		
		
		return sum;
		
		
		
	}

	public static int[] createArrayElement() 
	
	{
      Scanner s = new Scanner(System.in);
		
		int[] num = new int[5];
		
		for(int i =0;i<5;i++)
		{

		num[i]= s.nextInt();
		
		}
		
		System.out.println("array created");
		return num;
		
	}

	public static void displayArrayElement(int[] num)
	{
	
		for(int ele : num)
		{
			System.out.println(ele);
		}
		
		
	}

	
	
	
}

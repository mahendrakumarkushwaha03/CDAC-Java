package cdac;

import java.util.Scanner;

public class Employee 
{

	   void  displayEmp()
	   
	{  
		System.out.println("displaying emp details");
		
	}
	
	
	public static void main(String[] args) 
	{
		Employee e = new Employee();
	    e.displayEmp();
		
	}
	
}

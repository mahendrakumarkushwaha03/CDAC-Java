package cdac;

import java.util.Scanner;

public class ArrayExample
{

	public static void main(String[] args) 
	{
	
		int[] num = new int[4];
		
		String[] subject = {"c++","java","AI/ML","BigData"};
		
//		num[0] = 10;
//		num[1] = 20;
//		num[2] = 30;
//		num[3] = 40;
		
		Scanner s = new Scanner(System.in);
		 
        
		for(int i =0;i<4;i++)
		{

		num[i]= s.nextInt();
		
		}
			
			
		
for(int i =0;i<4;i++)
{

System.out.println(num[i]);
}
	


System.out.println("iterate String");


for(int i =0;i<4;i++)
{

System.out.println(subject[i]);
}

System.out.println("iterate using for each");


for(String ele :subject)
{
	System.out.println(ele);
}



}
	
	
}

package cdac;

public class EmployeeManagement 
{

	public static void create()
	{
		System.out.println("recored created inside the create method of"
				+ " EmployeeManagement class  ");
	}

	public static void delete() 
	{
		
		System.out.println("recored deleted inside the delete method of"
				+ " EmployeeManagement class  ");
	}
	
	
	
}

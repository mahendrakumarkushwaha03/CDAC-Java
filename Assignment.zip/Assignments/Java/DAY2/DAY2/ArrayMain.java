package cdac;

import java.util.Scanner;

public class ArrayMain 
{

	public static void main(String[] args) 
	{
	
		
		
		int[] num=ArrayManagement.createArrayElement();
		
		        ArrayManagement.displayArrayElement(num);
		        
		        
		int sum=ArrayManagement.sumofArrayElement(num);
		System.out.println("inside the main");
		System.out.println(sum);
		
		
		
	}
	
	
}

package cdac;

import java.util.Scanner;

public class ElectricityBillAmout 
{

	public static float findAmount(int unit)
	{
			float amount;		
				if(unit<=100)
				{
					amount = unit*1;
					
				}else if(unit<=200)
				{
					amount = 100+(unit-100)*2;
				}else if(unit<=300)
				{
					amount = 100+200+(unit-200)*3;
				}else
					amount = 100+200+300+(unit-300)*4;
				
			//	System.out.println(unit + " "+ amount);
			return amount;
			
				
				
		
	}
	
	
	
	
	
	public static void main(String[] args) 
	{
	
		System.out.println("enter the unit");
		Scanner s = new Scanner(System.in);
		
		int unit =s.nextInt();
		float amount=findAmount(unit);
		System.out.println(unit + " "+ amount);
		
		
	}
	
}

package cdac;

import java.util.Scanner;

public class Student
{

	int sid;
	String sname;
	float per;
		
	Student()
	{
		Scanner s = new Scanner(System.in);
		
		sid=s.nextInt();
		sname = s.next();
		per = s.nextFloat();
	}
	Student(int id,String na,float m)
	{
		
		
		sid=id;
		sname = na;
		per = m;
	}
	void displayStudent()
	{
		System.out.print(sid+sname+per);
	}
	
	
	void findGrade()
	{
		char grade;
		
		if(per>=80)
			grade = 'A';
		else
			grade = 'B';
		
		System.out.print(grade);
	}
	
	
}

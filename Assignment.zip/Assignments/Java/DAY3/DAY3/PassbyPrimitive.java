package cdac;

public class PassbyPrimitive
{


	public static void change(int a, int b) 
	{
		
		   a = 20;
		   b = 10;
		   
	}
		
	public static void main(String[] args) 
	{
	
		int a = 10;
		int b = 20;
		
		System.out.println(a + " "+ b );
		change(a,b);
		System.out.println(a + " "+ b );
		
	}

	
}

package cdac;

public class TestStudent 
{

	public static void main(String[] args) 
	{
	
		Student s1 = new Student(1001,"shan",44);
		
		s1.displayStudent();
		s1.findGrade();
		
		System.out.println();
		
		Student s2 = new Student(1002,"raj",90);
		s2.displayStudent();
		s2.findGrade();
		
		Student s3 = new Student();
		s3.displayStudent();
		s3.findGrade();
		
		
	}
}

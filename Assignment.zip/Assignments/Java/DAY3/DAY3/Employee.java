package cdac;

import java.util.Scanner;

public class Employee 
{

	int empno;
	String ename;
	float sal;

	public void displayEmployee()
	{
		System.out.println(empno);
		System.out.println(ename);
		System.out.println(sal);
	}

	public void readEmployee(int id,String na,float sa)
	{
	   // Scanner s = new Scanner(System.in);
	    empno = id;
	    ename = na;
	    sal = sa;
		
	}
	
	public void increaseSal()
	{
		sal = sal*0.01f;
		System.out.println("increased sal "+sal);
	}
	
	
	
}

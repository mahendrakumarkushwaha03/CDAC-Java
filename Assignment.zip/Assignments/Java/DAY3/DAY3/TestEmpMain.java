package cdac;

public class TestEmpMain
{

	public static void main(String[] args) 
	{
	
		System.out.println("enter the emp details");
		Employee e1 = new Employee();
		e1.readEmployee(1001,"shan",40000);
		e1.displayEmployee();
		e1.increaseSal();
//		e1.empno = 1001;
//		e1.ename = "nsnathan";
//		e1.sal = 30000;
		
//		System.out.println(e1.empno);
//		System.out.println(e1.ename);
//		System.out.println(e1.sal);
		
		
		
		Employee e2 = new Employee();
		e2.readEmployee(1002,"raj",50000);
		e2.displayEmployee();
		e2.increaseSal();
		
//		e2.empno = 1002;
//		e2.ename = "nathan";
//		e2.sal = 50000;
		
//		System.out.println(e2.empno);
//		System.out.println(e2.ename);
//		System.out.println(e2.sal);
		
		
		Employee e3 = new Employee();
		e3.readEmployee(1003,"guru",60000);
		e3.displayEmployee();
		e3.increaseSal();
		
//		System.out.println(e3.empno);
//		System.out.println(e3.ename);
//		System.out.println(e3.sal);
		
		
		Employee e4 = new Employee();
		
		
	}
	
	
}

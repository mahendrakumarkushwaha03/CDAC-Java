package cdac;

public class ArrayMain 
{

	public static void main(String[] args) 
	{
	
		int[] mark = {78,34,56,23,99};
		
		
		for(int n :mark)
		{
			System.out.println(n);
		}
		
		
		ArrayManagement.findMaxMark(mark);
		
		
	}
	
	
}

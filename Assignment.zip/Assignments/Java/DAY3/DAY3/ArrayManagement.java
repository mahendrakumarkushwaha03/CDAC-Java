package cdac;

public class ArrayManagement {

	public static void findMaxMark(int[] m)
	{
		int max = m[0];
		
		for(int ele : m)
		{
			
			if(ele>max)
			{
				max = ele;
			}
			
		}
		
		System.out.println("max mark = "+ max);
		
	}

}

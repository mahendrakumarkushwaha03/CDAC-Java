package cdac;

public class PassbyReference 
{

	public static void change(int[] mark)
	{
		
		mark[1]=44;
		
	}
	
	
	
	public static void main(String[] args) 
	{
	
		int[] mark = {78,34,56,23,99};
		
		System.out.println("actual");
		for(int n :mark)
		{
			System.out.println(n);
		}
		
		change(mark);
		System.out.println("after chanage");
		for(int n :mark)
		{
			System.out.println(n);
		}
		
		
	}

	
	
	
}

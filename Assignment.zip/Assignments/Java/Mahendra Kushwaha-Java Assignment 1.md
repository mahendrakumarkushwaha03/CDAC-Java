Problem Statements



**1. Declare length and width as double variables and calculate the area of a rectangle using arithmetic operators.**



package Jackie;

import java.util.Scanner;



public class Cheeta {

&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	double length = sc.nextInt();

&#x09;	int width = sc.nextInt();

&#x09;	System.out.println("Area is :" + length\*width);

&#x09;}



}





**2. Declare temperature in Celsius (double) and convert it to Fahrenheit using the formula ( F = (C × 9/5) + 32 ).**



package Jackie;



import java.util.Scanner;



public class Cheeta2 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter a number :");

&#x09;	double cel = sc.nextDouble();

&#x09;	

&#x09;	double fas = ((cel \*9/5)+32);

&#x09;	

&#x09;	System.out.println("Temperature in Fahranite is :" + fas);

&#x09;	sc.close();



&#x09;}



}



**3. Declare three subject marks (int) and calculate the total and average using arithmetic operators.**



package Jackie;

import java.util.Scanner;



public class cheeta3 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter sub1 :"

&#x09;			);

&#x09;	int sub1 = sc.nextInt();

&#x09;	System.out.println("Enter sub2 :");

&#x09;	int sub2 = sc.nextInt();

&#x09;	System.out.println("Enter sub3 :");

&#x09;	int sub3 = sc.nextInt();

&#x09;	int sum = (sub1 + sub2 +sub3);

&#x09;	int avg = ((sub1 + sub2 +sub3)/3);

&#x09;	System.out.println("total marks is:" + sum);

&#x09;	System.out.println("avg marks is:" + avg + " Sum is :"+sum);

&#x09;}



}





**4. Declare two integer variables and swap their values without using a third variable (use arithmetic operators only).**



package Jackie;

import java.util.Scanner;



public class cheeta4 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter num1 : ");

&#x09;	int num1 = sc.nextInt();

&#x09;	System.out.println("Enter num2 : ");

&#x09;	int num2 = sc.nextInt();

&#x09;	num1 = num1+num2;

&#x09;	num2 = num1-num2;

&#x09;	num1 = num1-num2;

&#x09;	System.out.println("Number num1 after swapping : " +num1);

&#x09;	System.out.println("Number num2 after swapping : " +num2);

&#x09;}



}





**5. Declare product price and discount percentage (double) and calculate the final price after applying the discount.**



package Jackie;

import java.util.Scanner;



public class cheeta5 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter Product Price : ");

&#x09;	double price = sc.nextDouble();

&#x09;	System.out.println("Enter Discount %: ");

&#x09;	double dis = sc.nextDouble();

&#x09;	double cal = price \* dis;

&#x09;	System.out.println("Final Price is :" + cal);

&#x09;}



}



**6. Declare student name (String) and marks (int); print “Pass” if marks ≥ 40, otherwise print “Fail”.**



package Jackie;

import java.util.Scanner;

public class cheeta6 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter the Student Name : ");

&#x09;	String Name=sc.next();

&#x09;	System.out.println("Enter the marks : ");

&#x09;	int marks = sc.nextInt();

&#x09;	if (marks>=40) {

&#x09;		System.out.println(Name + " is pass");

&#x09;	}else

&#x09;	{

&#x09;		System.out.println(Name + " is fail");

&#x09;	}

&#x09;}

}



**7. Declare an integer and check whether it is even or odd using modulus operator and if-else statement.**





package Jackie;

import java.util.Scanner;

public class Cheeta7 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter a number: ");

&#x09;	int num = sc.nextInt();

&#x09;	if (num%2==0) {

&#x09;		System.out.println("It is Even..!!");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("It is Odd..!!");

&#x09;	}

&#x09;}



}





**8. Declare two integers and print the largest number using relational operators and if-else statement.**



package Jackie;

import java.util.Scanner;



public class Cheeta8 {

&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter a number 1: ");

&#x09;	int num1 = sc.nextInt();

&#x09;	System.out.println("Enter a number 2: ");

&#x09;	int num2 = sc.nextInt();

&#x09;	if(num1>num2) {

&#x09;		System.out.println("Number 1 is greater");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("Number 2 is greater");

&#x09;	}

&#x09;}



}



**9. Declare principal (double), rate (double), and time (int); calculate simple interest and display whether it is high or low based on value.**



package Jackie;

import java.util.Scanner;



public class Cheeta9 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter Principal: ");

&#x09;	double principal = sc.nextDouble();

&#x09;	System.out.println("Enter Rate: ");

&#x09;	double Rate = sc.nextDouble();

&#x09;	System.out.println("Enter Time: ");

&#x09;	int Time = sc.nextInt();

&#x09;	

&#x09;	double Simple = principal\*Rate\*Time;

&#x09;	System.out.println("Simple Intrest is :" + Simple);

&#x09;	

&#x09;	if (Rate >9) {

&#x09;		System.out.println("It is High in Value..!!");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("It is Low in Value..!!");



&#x09;	}

&#x09;}

&#x09;

}



**10. Declare age (int) and display whether the person is Child, Teenager, or Adult using if-else-if ladder.**



package Jackie;

import java.util.Scanner;



public class Cheeta10 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter a age: ");

&#x09;	double age = sc.nextDouble();

&#x09;	if(age<18) {

&#x09;		System.out.println("child");

&#x09;	

&#x09;	}else if(age>=18 \&\& age<=21) {

&#x09;		System.out.println("Teenager");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("Adult");

&#x09;	}



&#x09;}



}



**11. Declare basic salary (double) and calculate final salary after adding bonus based on given condition.**



package Jackie;

import java.util.Scanner;



public class cheeta11 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter Basic Salary: ");

&#x09;	double BSal = sc.nextDouble();

&#x09;	

&#x09;	System.out.println("Enter Bonus: ");

&#x09;	double Bonus = sc.nextDouble();

&#x09;	System.out.println("Final Salary is: " + (BSal+Bonus));



&#x09;}



}



**12. Declare a character variable and check whether it is uppercase or lowercase using relational operators.**



package Jackie;

import java.util.Scanner;



public class Cheeta12 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter a Character: ");

&#x09;	char Ch = sc.next().charAt(0);

&#x09;	

&#x09;	if (Character.isUpperCase(Ch)) {

&#x20;           System.out.println("The character '" + Ch + "' is an uppercase letter.");

&#x20;       } 

&#x09;	

&#x09;	else if (Character.isLowerCase(Ch)) {

&#x09;		System.out.println("The character '" + Ch + "' is a lowercase letter.");

&#x20;       } 

&#x09;	else{

&#x20;           System.out.println("The character '" + Ch + "' is not an alphabetic character (e.g., it's a number or special character).");

&#x20;       }

&#x09;}



}



**13. Declare an integer and check whether the number is positive, negative, or zero.**



package Jackie;

import java.util.Scanner;



public class Cheeta13 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter number: ");

&#x09;	int num = sc.nextInt();

&#x09;	if(num==0) {

&#x09;		System.out.println("It is Zero or Neutral");

&#x09;	}

&#x09;	else if(num>0) {

&#x09;		System.out.println("It is Positive");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("Negative");

&#x09;	}

&#x09;}



}



**14. Declare number of electricity units (int) and calculate total bill amount based on given rate conditions.**



package Jackie;

import java.util.Scanner;



public class Cheeta14 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter Units: ");

&#x09;	int unit = sc.nextInt();

&#x09;	int amount=0;

&#x09;	if(unit<100) {

&#x09;		amount = unit\*1;

&#x09;	}

&#x09;	else if(unit<200) {

&#x09;		amount = 100+ (unit-100)\*2;

&#x09;	}

&#x09;	else if(unit<300) {

&#x09;		amount = 100+200+(unit-200)\*3;

&#x09;	}

&#x09;	else {

&#x09;		amount = 100 + 200+ 300+ (unit-300)\*4;

&#x09;	}

&#x09;	System.out.println("The amount is  :  " + amount);

&#x09;}



}



**15. Declare age (int) and check whether a person is eligible to vote using if-else statement.**



package Jackie;

import java.util.Scanner;

public class Cheeta15 {



&#x09;public static void main(String\[] args) {

&#x09;	Scanner sc = new Scanner(System.in);

&#x09;	System.out.println("Enter Age: ");

&#x09;	int num = sc.nextInt();

&#x09;	

&#x09;	

&#x09;	if(num>=18) {

&#x09;		System.out.println("Eligible");

&#x09;	}

&#x09;	else {

&#x09;		System.out.println("Not eligible");

&#x09;	}

&#x09;}



}




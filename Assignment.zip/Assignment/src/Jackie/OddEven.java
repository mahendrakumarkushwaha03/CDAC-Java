package Jackie;
import java.util.Scanner;

public class OddEven {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = sc.nextInt();
		
		String result = oddCal(num);
		System.out.println("The number " + num + " is " + result);
	}
	
	public static String oddCal(int num) {
		String val;
		if (num%2==0) {
			return "Even..!!";
		}
		else {
			return "Odd..!!";
		}
		
		
	}

}

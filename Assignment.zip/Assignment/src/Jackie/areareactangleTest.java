package Jackie;
import java.util.Scanner;


public class areareactangleTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Length :");
		int len = sc.nextInt();
		System.out.println("Enter Width :");
		int wid = sc.nextInt();
		
		areaofreactangle A1 = new areaofreactangle();
		A1.readData(len,wid);
		System.out.println("Area of rectangle is : "+ A1.calculateArea(len, wid));
		
	}

}

package Jackie;
import java.util.Scanner;

public class Max2Num {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number 1: ");
		int num1 = sc.nextInt();
		System.out.println("Enter a number 2: ");
		int num2 = sc.nextInt();
		
		String res = getnum(num1,num2);
		System.out.println("Greater Number is :" + res);

	}

	public static String getnum(int num1, int num2) {
		if (num1>num2){
			return (""+num1);
		}
		else {
			return (""+num2);
		}
	}

}

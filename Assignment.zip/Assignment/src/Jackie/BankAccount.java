package Jackie;
import java.util.Scanner;

public class BankAccount
{
	int accountnum;
	double balance;

		
public void readData(int ac,double bal){
	
		accountnum = ac;
		balance = bal;
}

public void deposit(int depo, double bal) {
	balance = this.balance+depo;
	System.out.println("amount deposited.."+ bal);
	
}

public void withdrawal(int with, double balance) {
	if(balance>1000){
		double res=(this.balance-with);
		System.out.println("Amount Left :"+res);
		
	}
	else {
		System.out.println("insufficient balanced !!");
	}
}


}







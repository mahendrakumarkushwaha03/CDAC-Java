package Jackie;
import java.util.Scanner;

public class votingeligibility {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Age: ");
		int num = sc.nextInt();
		
		String res = vote(num);
		System.out.println("The voter is " + res);

	}
	
	public static String vote(int num){
		if(num>=18) {
			return "Eligible";
		}
		else {
			return "Not eligible";
		}
	}

}

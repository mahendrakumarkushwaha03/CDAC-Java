package Jackie;
import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Table you want: ");
		int num = sc.nextInt();
		
		table(num);
	}

	public static void table(int num){
		int i=1;
		int mul;
		while(i<=10) {
			mul = num*i;
			System.out.println( num +"x"+ i +" is =" + mul);
			i+=1;
		}
		
		
	}

}

package Jackie;
import java.util.Scanner;
public class positivenegativezero {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number :");
		int num = sc.nextInt();
		
		String res = out(num);
		System.out.println(res);
		
	}

	public static String out(int num) {
		
		if(num ==0) {
			return (num + " is Zero");
		}
		else if (num>0) {
			return (num+ " is Positive");
		}
		else {
			return (num+ " is Negative");
		}
		
	}

}

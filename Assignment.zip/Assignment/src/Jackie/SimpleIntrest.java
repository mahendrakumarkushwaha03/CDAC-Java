package Jackie;

import java.util.Scanner;

public class SimpleIntrest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Principal: ");
		double principal = sc.nextDouble();
		System.out.println("Enter Rate: ");
		double Rate = sc.nextDouble();
		System.out.println("Enter Time: ");
		double Time = sc.nextDouble();
		
		double Result = Simp(principal,Rate,Time);
		System.out.println("Simple Interest is :" + Result);
	}

	public static double Simp(double principal,double Rate, double Time){
		return ((principal*Rate*Time)/100);

	}
}

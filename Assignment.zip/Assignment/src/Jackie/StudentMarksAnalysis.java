package Jackie;
import java.util.Scanner;

import org.graalvm.compiler.virtual.phases.ea.PartialEscapeBlockState.Final;

public class StudentMarksAnalysis {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("How many student's Data you want to enter : ");
		int Stu = sc.nextInt();
		
		int i;
		int [] marks = new int[Stu];
		
		for(i=0 ; i<Stu ;i++) {
			marks[i] = sc.nextInt();
		}

		int result = Final(marks); 
	}

	private static int Final(int[] marks) {
		int i;
		for(i=0; i<marks.length ; i++) {
			if(marks[i]>marks[i+1]) {
				int max = marks
			}
		}
		
		return 0;
	}

}

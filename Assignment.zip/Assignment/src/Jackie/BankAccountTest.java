package Jackie;
import java.util.Scanner;

public class BankAccountTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter bank account :");
		int ac = sc.nextInt();
		System.out.println("Enter bank balance :");
		double bal = sc.nextDouble(); 

		BankAccount B1 = new BankAccount();
		B1.readData(ac,bal);
		
		
		System.out.println("Enter amount to be deposit : ");
		int depo = sc.nextInt();
		B1.deposit(depo, bal);
		
		
		System.out.println("Enter amount to be Withdraw : ");
		int with = sc.nextInt();
		B1.withdrawal(with, bal);

	}

}

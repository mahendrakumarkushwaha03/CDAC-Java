package Jackie;

public class areaofreactangle {
	int length;
	int width;
	
	public void readData(int len, int wid){
		
		length = len;
		width = wid;
	}
	
	public int calculateArea(int len,int wid) {
		int area = len*wid;
		return area;
	}
}


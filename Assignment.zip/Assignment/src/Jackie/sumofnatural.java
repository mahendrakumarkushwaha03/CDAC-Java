package Jackie;
import java.util.Scanner;

public class sumofnatural {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Number till you want sum :");
		int num = sc.nextInt();
		
		int res = sumnum(num);
		System.out.println("The Sum of number " + num + " is : " + res );
	}

	public static int sumnum(int num) {
		int sum=0;
		for(int i=0; i<=num ;i++){
			sum=sum+i;
		}
		return sum;
	}

}

package Jackie;
import java.util.Scanner;

public class CountDigitNum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number: ");
		int num = sc.nextInt();
		
		int caldigit = calnum(num);
		
		System.out.println("Sum is : " + caldigit);
	}
	
	public static int calnum(int num){
		int sum = 0;
		int rem =0;
		while (num>0){
			rem= num%10;
			num= num/10;
			sum= sum+1;
		}
		return sum;
	}
	

}

package Jackie;

import java.util.Scanner;

public class SalaryBonusCal {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Basic Salary: ");
		
		double BSal = sc.nextDouble();
		double calculatedBonus = calculateBonus(BSal);
		
		
		System.out.println("The calculated bonus is: " + calculatedBonus);
        System.out.println("Total compensation: " + (BSal + calculatedBonus));
        
	}
	
	public static double calculateBonus(double BSal) {
    double total;
     
     if(BSal <=20000) {
			total = BSal * 0.10;
		}
		else if(BSal>20000 && BSal<=50000){
			total = BSal * 0.15;
		}
		else{
			total = BSal * 0.20;
		}
     return total;
     
	}
}
